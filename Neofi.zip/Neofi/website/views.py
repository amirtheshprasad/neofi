from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user 
from .models import Notes, User, Notes_archive
from . import db

views = Blueprint('views', __name__)


@views.route('/notes/create', methods = ['GET', 'POST'])
@login_required
def create_note():
    if request.method == 'POST':
        note_title = request.form.get('Note_title')
        note_description = request.form.get('Note_description')
        Note = Notes.query.filter_by(title = note_title).first()
        if Note:
            flash('Note already exists', category="error")
        else:
            new_note = Notes(title = note_title, description = note_description, owned = current_user.email, updated_by = current_user.email)
            db.session.add(new_note)
            db.session.commit()
            flash('Note created', category="success")
            return redirect(url_for('views.create_note'))

    return render_template("create_note.html")
    

@views.route('/notes/share', methods = ['GET', 'POST'])
@login_required
def share():
    if request.method == 'POST':
        note_title = request.form.get('Note_title')
        email = request.form.get('email')
        Note = Notes.query.filter_by(title = note_title).first()
        if Note:
            if Note.owned == current_user.email:
                shared_with = Note.shared_with
                if shared_with:
                    shared_with = shared_with + ',' + email
                else:
                    shared_with = email
             
                Note.shared_with = shared_with
                db.session.commit()
                flash('Note shared', category="success")
            else:
                flash('You are not the owner of the note and therefore you cannot share it', category="error")
            
        else:
            flash('Note does not exist', category="error")

    return render_template("share.html")


@views.route('/notes/<id>', methods = ['GET', 'POST'])
@login_required
def notes_id(id):
    Note = Notes.query.filter_by(id = id).first()
    if request.method == 'POST':
        new_note_archive = Notes_archive(note_id = id, title = Note.title, description = Note.description, updated_by = Note.updated_by, date = Note.date) 
        db.session.add(new_note_archive)
        db.session.commit()
        note_title = request.form.get('Note_title')
        note_description = request.form.get('Note_description')
        Note.title = note_title
        Note.description = note_description
        Note.updated_by = current_user.email
        db.session.commit()
        flash('Note updated', category="success")
    if Note.owned == current_user.email:
       
        return render_template("notes_id.html", data = Note)
    else:
        shared_with = Note.shared_with
        if shared_with:
            shared_with_list = shared_with.split(",")
            if current_user.email in shared_with_list:
            
                return render_template("notes_id.html", data = Note)
        else:
            return "<h1> You are not the owner and the note is not shared with you therefore you cannot view it </h1>"


@views.route('/notes/version-history/<id>', methods = ['GET', 'POST'])
@login_required
def version_history(id):

    Note = Notes.query.filter_by(id = id).first()
    notes_archive = Notes_archive.query.filter_by(note_id = id)
    if Note.owned == current_user.email:
       
        return render_template("version_history_id.html", data = Note, data2 = notes_archive)
    else:
        shared_with = Note.shared_with
        if shared_with:
            shared_with_list = shared_with.split(",")
            if current_user.email in shared_with_list:
         
                return render_template("version_history_id.html", data = Note, data2 = notes_archive)
            else:
                return "<h1> You are not the owner and the note is not shared with you therefore you cannot view it </h1>"
        else:
            return "<h1> You are not the owner and the note is not shared with you therefore you cannot view it </h1>"