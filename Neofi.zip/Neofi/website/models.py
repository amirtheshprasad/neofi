from . import db 
from flask_login import UserMixin
from sqlalchemy.sql import func 

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key = True)
    email = db.Column(db.String(150), unique = True)
    password = db.Column(db.String(150))
    name = db.Column(db.String(150))
    phone = db.Column(db.String(150))
    admin = db.Column(db.String(150))
    date = db.Column(db.DateTime(timezone = True), default = func.now())

class Notes(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    title = db.Column(db.String(1000))
    description = db.Column(db.String(2000))
    owner = db.column(db.String(1000))
    shared_with = db.Column(db.String(2000))
    updated_by = db.Column(db.String(1000))
    owned = db.Column(db.String(1000))
    date = db.Column(db.DateTime(timezone = True), default = func.now())

class Notes_archive(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    note_id = db.Column(db.Integer)
    title = db.Column(db.String(1000))
    description = db.Column(db.String(2000))
    updated_by = db.Column(db.String(1000))
    date = db.Column(db.DateTime(timezone = True), default = func.now())

    


