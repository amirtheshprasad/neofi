from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import User
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, login_required, logout_user, current_user 
import time


auth = Blueprint('auth', __name__)

@auth.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('exampleInputEmail1') 
        password = request.form.get('exampleInputPassword1')
        user = User.query.filter_by(email = email).first()
        if user:
            if user.password == password:
                flash('Logged in succesfully', category = 'success')
                login_user(user, remember = True)
                return redirect(url_for('views.create_note'))
            else:
                flash('Incorrect password, try again', category = 'error')
        else:
            flash('Email does not exist', category = 'error')

    return render_template("login.html")

@auth.route('/logout')
@login_required
def logout():
    flash('Logged out successfully', category = 'success')
    logout_user()
    # time.sleep(10)
    return redirect(url_for('auth.login'))

@auth.route('/signup', methods = ['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        name = request.form.get('Name')
        email = request.form.get('exampleInputEmail1') 
        password = request.form.get('exampleInputPassword1')
        phone = request.form.get('Phone')
        if email == 'amirtheshprasad@outlook.com':
            admin = 'True'
        else:
            admin = 'False'
        user = User.query.filter_by(email = email).first()
        if user:
            flash('Email already exists', category = 'error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters', category="error")
        elif len(name) < 1:
            flash('Name must be greater than 1 character', category= "error")
        elif len(password) < 7:
            flash('Password must be greater than 6 characters', category="error")
        elif len(phone) < 10:
            flash('Phone length is less than 10 digits', category="error")
        else:
            new_user = User(email= email, password = password, name= name, phone=phone, admin=admin)
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember = True)
            flash('Account created', category="success")
            return redirect(url_for('views.create_note'))
    return render_template("signup.html")

@auth.route('/change-password', methods = ['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        new_password = request.form.get('Password')
        if len(new_password)<7:
            flash('Password must be greater than 6 characters', category="error")
        elif current_user.password == new_password:
            flash('Password is the same as old password', category="error")
        else:
            current_user.password = new_password
            db.session.commit()
            flash('Password Changed', category="success")
    return render_template('changepassword.html')